<?php
// login.php

// Check for cookie first
if (isset($_COOKIE['session_cookie'])) {
    $cookie = $_COOKIE['session_cookie'];
    $last4 = substr($cookie, -4);
    $username = substr($cookie, 0, -4);

    if (file_exists('users.json')) {
        $users = json_decode(file_get_contents('users.json'), true);

        foreach ($users as $user) {
            if ($user['username'] == $username && substr($user['password'], -4) == $last4) {
                echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Login</title>
    <link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>
    <div class='greeting'>Hello " . $user['firstname'] . " " . $user['lastname'] . "! Your cookie is: " . $cookie . "</div>
    <script src=\"script.js\"></script>
</body>
</html>";
                exit;
            }
        }
    }
}

// If not logged in via cookie, check for login attempt
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['username']) && isset($_GET['password'])) {
    $username = $_GET['username'];
    $password = $_GET['password'];

    if (file_exists('users.json')) {
        $users = json_decode(file_get_contents('users.json'), true);

        foreach ($users as $user) {
            if ($user['username'] == $username && $user['password'] == $password) {
                $cookie_value = $username . substr($password, -4);
                setcookie("session_cookie", $cookie_value, time() + 3600, "/");

                echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Login</title>
    <link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>
    <div class='greeting'>Hello " . $user['firstname'] . " " . $user['lastname'] . "! Your cookie is: " . $cookie_value . "</div>
    <script src=\"script.js\"></script>
</body>
</html>";
                exit;
            }
        }
    }

    $message = "<p class='error'>Invalid username or password.</p>";
}

// Show the form
echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Login</title>
    <link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>
    <h1>Login Page</h1>
    " . $message . "
    <form action=\"login.php\" method=\"get\">
        <label for=\"username\">Username:</label>
        <input type=\"text\" id=\"username\" name=\"username\"><br><br>
        
        <label for=\"password\">Password:</label>
        <input type=\"text\" id=\"password\" name=\"password\"><br><br>
        
        <input type=\"submit\" value=\"Login\">
    </form>
    <script src=\"script.js\"></script>
</body>
</html>";
?>
