// script.js
// No JavaScript functionality needed for this basic implementation
console.log("Script loaded");
