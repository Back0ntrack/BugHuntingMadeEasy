<?php
// register.php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $firstname = $_GET['firstname'];
    $lastname = $_GET['lastname'];
    $username = $_GET['username'];
    $password = $_GET['password'];

    $user = array(
        'firstname' => $firstname,
        'lastname' => $lastname,
        'username' => $username,
        'password' => $password
    );

    $users = array();
    if (file_exists('users.json')) {
        $users = json_decode(file_get_contents('users.json'), true);
    }

    $users[] = $user;

    file_put_contents('users.json', json_encode($users));

    echo "Registration successful! <a href='login.php'>Go to Login</a>";
}
?>
